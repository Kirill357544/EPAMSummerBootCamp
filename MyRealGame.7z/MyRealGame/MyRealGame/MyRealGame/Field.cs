﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRealGame
{
    class Field: Variables
    {
        Random random = new Random();
        private char[,] field;

        public Field()
        {
            field = new char[Width, Lenght];
        }

        public int PosX { get; set; }

        public int PosY { get; set; }

        public void SetUpPrincess()
        {
            PrincessPositionX = random.Next(0, 10);
            PrincessPositionY = random.Next(9, 10);
            PosX = PrincessPositionX;
            PosY = PrincessPositionY;
        }

        public void SetUpBombs()
        {
            while (Bombs < 10)
            {
                BombPositionX = random.Next(0, 10);
                BombPositionY = random.Next(0, 10);
                if ((field[BombPositionX, BombPositionY] != 'b') && 
                    (BombPositionX != 0) && (BombPositionY != 0) && 
                    (BombPositionX != PrincessPositionX) && 
                    (BombPositionY != PrincessPositionY))
                {
                    field[BombPositionX, BombPositionY] = 'b';
                    Bombs = Bombs + 1;
                }
            }
        }

        public void RemoveBombs(int posx, int posy)
        {
            field[posx, posy] = '.';
        }

        public char this[int index_1, int index_2]
        {
            get
            {
                return field[index_1, index_2];
            }             
        }  
    }
}
