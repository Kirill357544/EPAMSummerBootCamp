﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRealGame
{
    class Display
    {
        public void Visual(Field field, int posx, int posy, int hp)
        {
            Console.Clear();
            for (var i = 0; i < field.Width; i++)
            {
                for (var j = 0; j < field.Lenght; j++)
                {
                    if ((i == posx) &&
                        (j == posy))
                    {
                        Console.Write('Я' + "\t");
                    }
                    else if ((i == field.PosX) &&
                        (j == field.PosY))
                    {
                        Console.Write('П' + "\t");
                    }
                    else
                    {
                        Console.Write('.' + "\t");
                    }                   
                }
                Console.WriteLine();
            }       
            Console.WriteLine("\n" + "HP: {0}", hp);
        }
    }
}
