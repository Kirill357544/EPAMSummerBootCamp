﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRealGame
{
    class Variables
    {
        public int Width { get; set; } = 10;

        public int Lenght { get; set; } = 10;

        protected int Bombs { get; set; } = 0;

        protected int BombPositionX { get; set; } = 0;

        protected int BombPositionY { get; set; } = 0;

        protected int PrincessPositionX { get; set; } = 0;

        protected int PrincessPositionY { get; set; } = 0;

        public int PlayerPositionX { get; set; }

        public int PlayerPositionY { get; set; }
    }
}
