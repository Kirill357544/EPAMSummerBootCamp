﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRealGame
{
    class Player
    {
        Random random = new Random();
        Field field;
        Variables variables;

        public Player(ref Variables variables, Field field)
        {
            this.variables = variables;
            this.field = field;
        }

        public int PositionX 
        { 
            get
            {
                return variables.PlayerPositionX;
            }
            set
            {
                if ((value < variables.Width) && 
                    (value >= 0))
                {
                    variables.PlayerPositionX = value;
                }
            }
        }

        public int PositionY
        {
            get
            {
                return variables.PlayerPositionY;
            }
            set
            {
                if ((value < variables.Width) &&
                    (value >= 0))
                {
                    variables.PlayerPositionY = value;
                }
            }
        }

        public int HealthPoint { get; set; } = 10;

        public void Move(char key)
        {
            switch (key)
            {
                case 'w':
                    PositionX -= 1;
                    if(BlowUp())
                    {
                        Damage();
                        field.RemoveBombs(variables.PlayerPositionX, variables.PlayerPositionY);
                    }
                    break;

                case 's':
                    PositionX += 1;
                    if (BlowUp())
                    {
                        Damage();
                        field.RemoveBombs(variables.PlayerPositionX, variables.PlayerPositionY);
                    }
                    break;

                case 'd':
                    PositionY += 1;
                    if (BlowUp())
                    {
                        Damage();
                        field.RemoveBombs(variables.PlayerPositionX, variables.PlayerPositionY);
                    }
                    break;

                case 'a':
                    PositionY -= 1;
                    if (BlowUp())
                    {
                        Damage();
                        field.RemoveBombs(variables.PlayerPositionX, variables.PlayerPositionY);
                    }
                    break;

                default:
                    break;
            }
        }

        public bool BlowUp()
        {
            if(field[variables.PlayerPositionX, variables.PlayerPositionY] == 'b')
            {
                return true;
            }
            return false;
        }

        public void Damage()
        {
            HealthPoint -= random.Next(1,11);
        }

        public bool Death()
        {
            if (HealthPoint <= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
