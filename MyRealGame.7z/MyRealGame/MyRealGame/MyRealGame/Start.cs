﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRealGame
{
    class Start
    {
        Variables variables = new Variables();
        Field field = new Field();
        Display display = new Display();
        Player player;

        public void StartGame()
        {
            player = new Player(ref variables, field);
            variables.PlayerPositionX = 0;
            variables.PlayerPositionY = 0;
            field.SetUpPrincess();
            display.Visual(field, player.PositionX, player.PositionY, player.HealthPoint);
            field.SetUpBombs();
            ProcessGame();
        }

        public bool ProcessGame()
        {        
            char key = Console.ReadKey().KeyChar;
            player.Move(key);
            display.Visual(field, player.PositionX, player.PositionY, player.HealthPoint);
            if((player.PositionX == field.PosX) &&
                (player.PositionY == field.PosY))
            {
                Console.Clear();
                Console.WriteLine("You have won, press 'Y' to restart or 'N' to close application");
                switch (key)
                {
                    case 'y':
                        StartGame();
                        break;
                    case 'n':
                        Environment.Exit(0);
                        break;
                    default:
                        break;
                }
            }
            else if(player.Death())
            {
                Console.Clear();
                Console.WriteLine("You have lost, press 'Y' to restart or 'N' to close application");
                switch(key)
                {
                    case 'y':
                        StartGame();
                        break;
                    case 'n':
                        Environment.Exit(0);
                        break;
                    default:
                        break;
                }                   
            }
            return ProcessGame();
        }
    }
}
